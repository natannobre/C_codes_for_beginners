#include <stdio.h>
#include <stdlib.h>

int vogais(char c)
{
    return (c == 'a') || (c == 'e') || (c == 'i') || (c == 'o') || (c == 'u');
}
int main()
{
    char frase[101];
    int i;

    scanf("%100[^\n]", frase);

    for(i = 0; frase[i]; i++)
        if(vogais(frase[i]))
            printf("%c", frase[i]);
        printf("\n");

    for(i = 0; frase[i]; i++)
        if(!vogais(frase[i]) && (frase[i] != ' '))
            printf("%c", frase[i]);

    return 0;
}