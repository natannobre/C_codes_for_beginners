#include <stdio.h>
#include <stdlib.h>

int main()
{
    char frase[100], opcoes;
    int j;

    scanf("%99[^\n]", frase);
    scanf("\n%c", &opcoes);

        if(opcoes == 'M')
        {
            for(j = 0; frase[j]; j++)
            {
                if((frase[j] >= 'a') && (frase[j] <= 'z'))
                   frase[j] = frase[j] - 32;
            }
            printf("%s", frase);
        }
        if(opcoes == 'm')
        {
            for(j = 0; frase[j]; j++)
            {
                if((frase[j] >= 'A') && (frase[j] <= 'Z'))
                    frase[j] = frase[j] + 32;
            }
            printf("%s", frase);
        }
        if(opcoes == 'i')
        {
            for(j = 0; frase[j]; j++)
            {
               if((frase[j] >= 'a') && (frase[j] <= 'z'))
                    frase[j] = frase[j] - 32;
               else if((frase[j] >= 'A') && (frase[j] <= 'Z'))
                    frase[j] = frase[j] + 32;
            }
            printf("%s", frase);
        }
        if(opcoes == 'p')
        {
            if((frase[1] == ' ') && (frase[0] >= 'A') && (frase[0] <= 'Z'))
                frase[0] = frase[0] + 32;
            for(j = 1; frase[j]; j++)
            {
                if((frase[j] >= 'a') && (frase[j] <= 'z'))
                {
                    if((frase[j - 1] == ' ') && (frase[j + 1] >= 'a') && (frase[j + 1] <= 'z'))
                        frase[j] = frase[j] - 32;
                }
            }
            printf("%s", frase);
        }
    return 0;
}
