#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char frase1[100], frase2[100];
    int i, j;

    scanf("%99[^\n]", frase1);
    scanf("\n%99[^\n]", frase2);

    if(strlen(frase1) != strlen(frase2))
        printf("nao");
    else
    {
        for(i = 0; frase1[i]; i++)
        {
            for(j = 0; frase2[j]; j++)
            {
                if(frase1[i] == frase2[j])
                {
                    frase2[j] = ' ';
                    break;
                }
            }
            if(frase2[j] == 0)
            {
                printf("nao");
                return 0;
            }
        }
        printf("sim");
    }
}