#include <stdio.h>
#include <stdlib.h>

int contador(char frase[])
 {
     int i, cont = 0;
     for(i = 0; frase[i]; i++)
     {
         while((frase[i]) && (frase[i] != ' '))
             i++;
         while(frase[i] == ' ')
            i++;
            
            cont++;
         if(!frase[i])
            break;
     }
     return cont;
 }

 int conta_letras(char letra, char frase[])
 {
     int i, cont = 0;
     for(i = 0; frase[i]; i++)
     {
         if(letra == frase[i])
         {
             cont++;
            while((frase[i]) && (frase[i] != ' '))
                i++;
         }

     }
     return cont;
 }
int main()
{
    char letra;
    int cont = 0;

    char frase[100];
    scanf("%99[^\n]", frase);

    int palavras = contador(frase);

    for(letra = 'a'; letra <= 'z'; letra++)
    {
        if(conta_letras(letra, frase) == palavras)
            cont++;

    }
    printf("%d", cont);
}