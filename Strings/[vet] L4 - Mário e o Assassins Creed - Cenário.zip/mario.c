#include <stdio.h>
#include <stdlib.h>

int main()
{
    int qtd, maior = 0, i, nivel;

    scanf("%d", &qtd);

    int vetor[qtd];

    for(i = 0; i < qtd; i++)
    {
        scanf("%d", &vetor[i]);
        if(maior < vetor[i])
            maior = vetor[i];
    }
    for(nivel = maior; nivel >= 1; nivel--)
    {
        for(i = 0; i < qtd; i++)
        {
            if(nivel <= vetor[i])
                printf("#");
            else
                printf("_");
        }
        printf("\n");
    }
    return 0;
}