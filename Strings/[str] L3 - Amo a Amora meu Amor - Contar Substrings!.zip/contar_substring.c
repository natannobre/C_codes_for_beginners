#include <stdio.h>
#include <stdlib.h>

int main()
{
    char frase1[100], frase2[100];
    int i, contador = 0, aux = 0;

    scanf("%99[^\n]", frase1);
    scanf("\n%99[^\n]", frase2);

    for(i = 0; frase1[i]; i++)
    {
        if(frase1[i] == frase2[aux])
        {
            aux++;
            if(frase2[aux] == 0)
            {
                contador++;
                aux = 0;
            }
        }
        else
            aux = 0;
    }
    printf("%d", contador);

    return 0;
}