#include <stdio.h>
#include <stdlib.h>

int main()
{
    char frase1[100], frase2[100], frase3[100];
    int i, j;

    scanf("%99[^\n]", frase1);
    scanf("\n%99[^\n]", frase2);
    scanf("\n%99[^\n]", frase3);

    for(i = 0; frase1[i]; i++)
    {
        for(j = 0; frase2[j] && frase1[i + j]; j++)
            if(frase1[i + j] != frase2[j])
                break;
            if(frase2[j] == 0)
            {
                printf("%s", frase3);
                i = i + j - 1;
            }
            else
                printf("%c", frase1[i]);
    }
    return 0;
}