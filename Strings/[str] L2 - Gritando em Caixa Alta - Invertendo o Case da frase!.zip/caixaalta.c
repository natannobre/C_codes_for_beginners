#include <stdio.h>
#include <stdlib.h>

int m(char c)
{
    return (c >= 'a') && (c <= 'z');
}
int M(char c)
{
    return (c >= 'A') && (c <= 'Z');
}
int main()
{
    int i;
    char frase[101];

    scanf("%100[^\n]", frase);

    for(i = 0; frase[i]; i++)
    {
        if(m(frase[i]))
        {
            frase[i] = frase[i] - 32;
            printf("%c", frase[i]);
        }

        else if(M(frase[i]))
        {
            frase[i] = frase[i] + 32;
            printf("%c", frase[i]);
        }
        else
            printf("%c", frase[i]);
    }
}