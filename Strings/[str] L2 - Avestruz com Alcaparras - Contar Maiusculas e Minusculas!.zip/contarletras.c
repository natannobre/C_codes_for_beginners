#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
    char v[100];
    char letra = 'a';
    int i, a = 0, tstring = 0;

//    printf("DIGITE A FRASE: ");
    gets(v);
    tstring = strlen(v);

    if(tstring > 99)
        printf("FRASE MUITO GRANDE!");
    else
    {
//        printf("DIGITE A LETRA A SER CONTADA: ");
        scanf("%c", &letra);
        for(i = 0; i < tstring; i++)
        {
            if((v[i] == letra) || (v[i] == letra - 32) || (v[i] == letra + 32))
                a++;
        }
        printf("%d", a);
    }
    return 0;
}
