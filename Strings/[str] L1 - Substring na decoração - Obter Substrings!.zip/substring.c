#include <stdio.h>
#include <stdlib.h>

int main()
{
    char frase[100];
    int i, a1, a2, cont = 0;

    scanf("%99[^\n]", frase);
    scanf("%d", &a1);
    scanf("%d", &a2);

    for(i = a1; frase[i] != '\0' && cont < a2; i++)
    {
        printf("%c", frase[i]);
        cont++;
    }

    return 0;
}