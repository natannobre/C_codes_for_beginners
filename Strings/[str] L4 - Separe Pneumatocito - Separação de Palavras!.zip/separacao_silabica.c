#include <stdio.h>
#include <stdlib.h>

int main()
{
    char frase[100], aux;
    int i;

    scanf("%99[^\n]", frase);

    for(i = 0; frase[i]; i++)
    {
        printf("%c", frase[i]);
        if((frase[i] == 'a') || (frase[i] == 'e') || (frase[i] == 'i') || (frase[i] == 'o') || (frase[i] == 'u') || (frase[i] == 'A') || (frase[i] == 'E') || (frase[i] == 'I') || (frase[i] == 'O') || (frase[i] == 'U'))
        {
            if((frase[i + 1] != 'a') && (frase[i + 1] != 'e') && (frase[i + 1] != 'i') && (frase[i + 1] != 'o') && (frase[i + 1] != 'u') && (frase[i + 1] != '\0') && (frase[i + 1] != ' '))
            {
                printf("-");
            }
        }
    }

    return 0;
}