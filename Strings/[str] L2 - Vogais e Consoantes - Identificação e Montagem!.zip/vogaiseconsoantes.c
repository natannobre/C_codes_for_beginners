#include <stdio.h>
#include <stdlib.h>

int main()
{
    char frase[100];
    int i;

    scanf("%99[^\n]", frase);

    for(i = 0; frase[i]; i++)
    {
        if((frase[i] >= 'A') && (frase[i] <= 'Z'))
            frase[i] = frase[i] + 32;
    }

    for(i = 0; frase[i]; i++)
    {
        if((frase[i] == 'a') || (frase[i] == 'e') || (frase[i] == 'i') || (frase[i] == 'o') || (frase[i] == 'u'))
            frase[i] = 'v';
        else if((frase[i] != 'a') && (frase[i] != 'e') && (frase[i]  != 'i') && (frase[i] != 'o') && (frase != 'u') &&( frase[i] != ' '))
            frase[i] = 'c';
        else if(frase[i] == ' ')
            frase[i] = ' ';
    }
    printf("%s", frase);
    return 0;
}